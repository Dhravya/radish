# CHANGELOG.md

## [1.0.0] - 2024-02-28

First release
